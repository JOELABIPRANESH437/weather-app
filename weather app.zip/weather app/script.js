const apiKey = "82e8ed4f6968903174375ddd7041bdf8";
const geoApiUrl = "https://api.openweathermap.org/geo/1.0/direct?q=";
const apiUrl = "https://api.openweathermap.org/data/2.5/weather?units=metric&q=";

const searchBox = document.querySelector("#city-input");
const searchBtn = document.querySelector("#search-button");
const suggestionsList = document.querySelector("#suggestions");
const weatherIcon = document.querySelector(".weather-icon");

async function fetchCitySuggestions(cityName) {
    const response = await fetch(`${geoApiUrl}${cityName}&limit=5&appid=${apiKey}`);
    const cities = await response.json();
    

    console.log("City Suggestions:", cities);
    
    return cities;
}


searchBox.addEventListener("input", async function() {
    const inputValue = searchBox.value.trim();


    if (inputValue) {
        const citySuggestions = await fetchCitySuggestions(inputValue);
        showSuggestions(citySuggestions);
    } else {
        suggestionsList.innerHTML = "";
    }
});


function showSuggestions(cities) {
    suggestionsList.innerHTML = ""; 

    cities.forEach(city => {
        const listItem = document.createElement("li");
        listItem.textContent = `${city.name}, ${city.country}`;
        
      
        listItem.addEventListener("click", () => {
            searchBox.value = city.name;

          
            console.log("Selected City Details:", city);
            
         
            document.querySelector(".city").innerHTML = `${city.name}, ${city.country}`;
            document.querySelector(".temp").innerHTML = `Latitude: ${city.lat}, Longitude: ${city.lon}`;
            
            suggestionsList.innerHTML = ""; 
        });
        suggestionsList.appendChild(listItem);
    });
}


async function checkWeather(city) {
    const response = await fetch(apiUrl + city + `&appid=${apiKey}`);
    
    if (response.status === 404) {
        document.querySelector(".error").style.display = "block";
        document.querySelector(".weather").style.display = "none";
    } else {
        const data = await response.json();

       
        console.log(data);

        document.querySelector(".city").innerHTML = data.name;
        document.querySelector(".temp").innerHTML = Math.round(data.main.temp) + "°C";
        document.querySelector(".humidity").innerHTML = data.main.humidity + "%";
        document.querySelector(".wind").innerHTML = data.wind.speed + " km/h";

        
        if (data.weather[0].main === "Clouds") {
            weatherIcon.src = "images/clouds.png";
        } else if (data.weather[0].main === "Clear") {
            weatherIcon.src = "images/clear.png";
        } else if (data.weather[0].main === "Rain") {
            weatherIcon.src = "images/rain.png";
        } else if (data.weather[0].main === "Drizzle") {
            weatherIcon.src = "images/drizzle.png";
        } else if (data.weather[0].main === "Mist") {
            weatherIcon.src = "images/mist.png";
        }

        document.querySelector(".weather").style.display = "block";
        document.querySelector(".error").style.display = "none";
    }
}

searchBtn.addEventListener("click", () => {
    checkWeather(searchBox.value);
});
